# Scheduled Alerts - Snowflake UDFs and Procedures
