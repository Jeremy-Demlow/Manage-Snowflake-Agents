-- =============================================================================
-- Ski Resort Analytics - Email Sending Procedure
-- =============================================================================
-- Creates a stored procedure to send formatted HTML emails via Snowflake.
-- All objects are created in SKI_RESORT_DB.AGENTS schema.
-- =============================================================================

USE DATABASE SKI_RESORT_DB;
USE SCHEMA AGENTS;

-- =============================================================================
-- STEP 1: Create email notification integration (requires ACCOUNTADMIN)
-- =============================================================================
-- Uncomment and run as ACCOUNTADMIN if you don't have an email integration:
/*
USE ROLE ACCOUNTADMIN;

CREATE NOTIFICATION INTEGRATION IF NOT EXISTS SKI_RESORT_EMAIL_INTEGRATION
  TYPE = EMAIL
  ENABLED = TRUE;

GRANT USAGE ON INTEGRATION SKI_RESORT_EMAIL_INTEGRATION TO ROLE SYSADMIN;
*/

-- =============================================================================
-- STEP 2: Create the email stored procedure
-- =============================================================================
CREATE OR REPLACE PROCEDURE SKI_RESORT_DB.AGENTS.SEND_FORMATTED_EMAIL(
  RECIPIENT STRING,
  SUBJECT STRING,
  RAW_HTML STRING
)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = 3.11
PACKAGES = ('snowflake-snowpark-python', 'premailer')
HANDLER = 'send_formatted_email'
EXECUTE AS CALLER
COMMENT = 'Send formatted HTML email using Snowflake email integration'
AS
$$
import premailer

# Update this to match your email integration name
INTEGRATION_NAME = "SKI_RESORT_EMAIL_INTEGRATION"

def send_formatted_email(session, recipient: str, subject: str, raw_html: str) -> str:
    """
    Inline CSS with premailer, then send HTML email via system$send_email.

    Premailer transforms CSS <style> tags to inline styles, which is required
    because most email clients strip <style> tags but keep inline CSS.
    """
    try:
        # Transform CSS to inline styles for email compatibility
        formatted_html = premailer.transform(raw_html)

        # Send via Snowflake's built-in email system
        session.call(
            'system$send_email',
            INTEGRATION_NAME,
            recipient,
            subject,
            formatted_html,
            'text/html',
        )
        return f"Email sent successfully to {recipient}"

    except Exception as e:
        return f"Failed to send email: {type(e).__name__}: {e}"
$$;

-- =============================================================================
-- STEP 3: Grant permissions
-- =============================================================================
GRANT USAGE ON PROCEDURE SKI_RESORT_DB.AGENTS.SEND_FORMATTED_EMAIL(STRING, STRING, STRING) TO ROLE SYSADMIN;

-- =============================================================================
-- STEP 4: Test the email procedure (update email address first!)
-- =============================================================================
/*
CALL SKI_RESORT_DB.AGENTS.SEND_FORMATTED_EMAIL(
    'your.email@example.com',
    '🎿 Test Email from Ski Resort Analytics',
    '<html>
    <body style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; padding: 20px; background: #f5f5f5;">
        <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <div style="background: linear-gradient(135deg, #1e88e5 0%, #1565c0 100%); padding: 30px; color: white;">
                <h1 style="margin: 0; font-size: 22px;">🎿 Ski Resort Analytics</h1>
                <p style="margin-top: 8px; opacity: 0.9;">Test Email</p>
            </div>
            <div style="padding: 30px;">
                <p>This is a test email to verify your email integration is working correctly.</p>
                <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin-top: 20px; border-left: 4px solid #1976d2;">
                    <strong>✅ Test successful!</strong><br>
                    Your scheduled alerts will look similar to this.
                </div>
            </div>
        </div>
    </body>
    </html>'
);
*/

-- =============================================================================
-- IMPORTANT NOTES
-- =============================================================================
--
-- 1. VERIFY EMAIL ADDRESSES
--    Recipients must verify their email addresses before receiving emails.
--    Users can do this in Snowsight: User Menu → My Profile → Verify Email
--
-- 2. EMAIL INTEGRATION REQUIRED
--    You need an email notification integration created by ACCOUNTADMIN.
--
-- 3. RATE LIMITS
--    Snowflake has email rate limits. For high-volume alerting, consider
--    using an external email service (SendGrid, AWS SES, etc.)
--
-- 4. HTML FORMATTING
--    Use inline CSS or simple HTML. Many email clients strip <style> tags.
--    The premailer library handles this automatically.
