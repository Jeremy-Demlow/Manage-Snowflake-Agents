-- =============================================================================
-- Ski Resort Analytics - Scheduled Alerts Setup
-- =============================================================================
-- All objects are created in SKI_RESORT_DB.AGENTS schema.
--
-- KEY FEATURE: When you subscribe, the first alert is sent immediately
-- so you can preview what you'll receive on the schedule.
-- =============================================================================

USE DATABASE SKI_RESORT_DB;
USE SCHEMA AGENTS;

-- Create stage for Python code
CREATE STAGE IF NOT EXISTS SKI_RESORT_DB.AGENTS.ALERTS_STAGE;

-- =============================================================================
-- STEP 1: Create the alerts table
-- =============================================================================
CREATE TABLE IF NOT EXISTS SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS (
    ALERT_ID NUMBER AUTOINCREMENT,
    USER_EMAIL VARCHAR NOT NULL,
    OVERALL_QUESTION VARCHAR NOT NULL,
    ALERT_FREQUENCY VARCHAR NOT NULL DEFAULT 'Daily',
    AGENT_NAME VARCHAR DEFAULT 'RESORT_EXECUTIVE_DEV',
    IS_ACTIVE BOOLEAN DEFAULT TRUE,
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    LAST_SENT_AT TIMESTAMP_NTZ,
    SEND_COUNT NUMBER DEFAULT 0,
    PRIMARY KEY (ALERT_ID)
);

-- =============================================================================
-- STEP 2: Core function - Send an alert NOW with REAL DATA insights
-- This queries actual data and generates a beautiful formatted report
-- =============================================================================
CREATE OR REPLACE PROCEDURE SKI_RESORT_DB.AGENTS.SEND_ALERT_NOW(
    USER_EMAIL STRING,
    QUESTION STRING
)
RETURNS STRING
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    EMAIL_SUBJECT STRING;
    EMAIL_BODY STRING;
    REPORT_DATE STRING;
    TICKET_REV NUMBER;
    RENTAL_REV NUMBER;
    FNB_REV NUMBER;
    TOTAL_REV NUMBER;
    VISITORS NUMBER;
    TICKET_PCT NUMBER;
    RENTAL_PCT NUMBER;
    FNB_PCT NUMBER;
    REV_PER_VISITOR NUMBER;
    INSIGHTS STRING;
BEGIN
    -- Get date for report
    SELECT TO_VARCHAR(CURRENT_DATE(), 'Month DD, YYYY') INTO :REPORT_DATE;

    -- Get ticket revenue
    SELECT COALESCE(ROUND(SUM(PURCHASE_AMOUNT), 0), 0)
    INTO :TICKET_REV
    FROM SKI_RESORT_DB.MARTS.FACT_TICKET_SALES t
    JOIN SKI_RESORT_DB.MARTS.DIM_DATE d ON t.PURCHASE_DATE_KEY = d.DATE_KEY
    WHERE d.FULL_DATE >= DATEADD(day, -7, CURRENT_DATE());

    -- Get rental revenue
    SELECT COALESCE(ROUND(SUM(RENTAL_AMOUNT), 0), 0)
    INTO :RENTAL_REV
    FROM SKI_RESORT_DB.MARTS.FACT_RENTALS r
    JOIN SKI_RESORT_DB.MARTS.DIM_DATE d ON r.RENTAL_DATE_KEY = d.DATE_KEY
    WHERE d.FULL_DATE >= DATEADD(day, -7, CURRENT_DATE());

    -- Get F and B revenue
    SELECT COALESCE(ROUND(SUM(TOTAL_AMOUNT), 0), 0)
    INTO :FNB_REV
    FROM SKI_RESORT_DB.MARTS.FACT_FOOD_BEVERAGE f
    JOIN SKI_RESORT_DB.MARTS.DIM_DATE d ON f.TRANSACTION_DATE_KEY = d.DATE_KEY
    WHERE d.FULL_DATE >= DATEADD(day, -7, CURRENT_DATE());

    -- Get unique visitors
    SELECT COALESCE(COUNT(DISTINCT CUSTOMER_KEY), 0)
    INTO :VISITORS
    FROM SKI_RESORT_DB.MARTS.FACT_PASS_USAGE p
    JOIN SKI_RESORT_DB.MARTS.DIM_DATE d ON p.DATE_KEY = d.DATE_KEY
    WHERE d.FULL_DATE >= DATEADD(day, -7, CURRENT_DATE());

    -- Calculate totals and percentages
    TOTAL_REV := TICKET_REV + RENTAL_REV + FNB_REV;
    TICKET_PCT := CASE WHEN TOTAL_REV > 0 THEN ROUND(TICKET_REV / TOTAL_REV * 100, 0) ELSE 0 END;
    RENTAL_PCT := CASE WHEN TOTAL_REV > 0 THEN ROUND(RENTAL_REV / TOTAL_REV * 100, 0) ELSE 0 END;
    FNB_PCT := CASE WHEN TOTAL_REV > 0 THEN ROUND(FNB_REV / TOTAL_REV * 100, 0) ELSE 0 END;
    REV_PER_VISITOR := CASE WHEN VISITORS > 0 THEN ROUND(TOTAL_REV / VISITORS, 0) ELSE 0 END;

    -- Build insights text
    INSIGHTS := 'WEEKLY PERFORMANCE SUMMARY (Last 7 Days)

TOTAL REVENUE: $' || TO_VARCHAR(TOTAL_REV, '999,999,999') || '

Revenue by Business Unit:
- Tickets: $' || TO_VARCHAR(TICKET_REV, '999,999,999') || ' (' || TICKET_PCT || '%)
- Rentals: $' || TO_VARCHAR(RENTAL_REV, '999,999,999') || ' (' || RENTAL_PCT || '%)
- Food and Beverage: $' || TO_VARCHAR(FNB_REV, '999,999,999') || ' (' || FNB_PCT || '%)

Unique Visitors: ' || TO_VARCHAR(VISITORS, '999,999') || '
Revenue per Visitor: $' || REV_PER_VISITOR || '

INSIGHTS:
' || CASE WHEN FNB_PCT > 25 THEN '- F and B team delivering strong results at ' || FNB_PCT || '% of revenue!'
         ELSE '- F and B at ' || FNB_PCT || '% - consider promotions to boost ancillary revenue' END || '
' || CASE WHEN REV_PER_VISITOR > 100 THEN '- Excellent per-visitor spend at $' || REV_PER_VISITOR
         ELSE '- Per-visitor spend of $' || REV_PER_VISITOR || ' has room for growth' END || '

RECOMMENDATIONS:
- ' || CASE WHEN TICKET_PCT > 50 THEN 'Ticket revenue is healthy - maintain pricing strategy'
           ELSE 'Consider ticket bundling to increase ticket revenue share' END || '
- ' || CASE WHEN RENTAL_PCT > 15 THEN 'Rental performance is solid'
           ELSE 'Explore rental package promotions' END || '

Your Question: ' || :QUESTION || '
---
Data from SKI_RESORT_DB | ' || :REPORT_DATE;

    -- Build email subject
    EMAIL_SUBJECT := 'Resort Performance Report - ' || :REPORT_DATE;

    -- Build HTML email
    EMAIL_BODY := '<!DOCTYPE html><html><head><style>
body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 0; padding: 0; background: #f5f5f5; }
.container { max-width: 600px; margin: 20px auto; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.header { background: linear-gradient(135deg, #1e88e5, #1565c0); padding: 25px; color: white; border-radius: 12px 12px 0 0; }
.content { padding: 25px; }
.insights { background: #e3f2fd; padding: 20px; border-radius: 8px; border-left: 4px solid #1976d2; white-space: pre-wrap; line-height: 1.7; font-size: 14px; }
.metrics { display: flex; flex-wrap: wrap; gap: 15px; margin: 20px 0; }
.metric { background: #f8f9fa; padding: 15px; border-radius: 8px; flex: 1; min-width: 120px; text-align: center; }
.metric-value { font-size: 20px; font-weight: bold; color: #1565c0; }
.metric-label { font-size: 11px; color: #666; margin-top: 5px; }
.footer { background: #fafafa; padding: 15px; font-size: 12px; color: #666; text-align: center; border-radius: 0 0 12px 12px; }
</style></head><body>
<div class="container">
<div class="header">
<h1 style="margin:0; font-size: 18px;">Resort Performance Report</h1>
<div style="opacity: 0.9; margin-top: 8px; font-size: 13px;">' || :REPORT_DATE || ' - Last 7 Days</div>
</div>
<div class="content">
<div class="metrics">
<div class="metric"><div class="metric-value">$' || TO_VARCHAR(ROUND(TOTAL_REV/1000, 0)) || 'K</div><div class="metric-label">TOTAL REVENUE</div></div>
<div class="metric"><div class="metric-value">' || TO_VARCHAR(VISITORS, '999,999') || '</div><div class="metric-label">VISITORS</div></div>
<div class="metric"><div class="metric-value">$' || REV_PER_VISITOR || '</div><div class="metric-label">PER VISITOR</div></div>
</div>
<div class="metrics">
<div class="metric"><div class="metric-value">$' || TO_VARCHAR(ROUND(TICKET_REV/1000, 0)) || 'K</div><div class="metric-label">TICKETS (' || TICKET_PCT || '%)</div></div>
<div class="metric"><div class="metric-value">$' || TO_VARCHAR(ROUND(RENTAL_REV/1000, 0)) || 'K</div><div class="metric-label">RENTALS (' || RENTAL_PCT || '%)</div></div>
<div class="metric"><div class="metric-value">$' || TO_VARCHAR(ROUND(FNB_REV/1000, 0)) || 'K</div><div class="metric-label">F and B (' || FNB_PCT || '%)</div></div>
</div>
<h3 style="color: #1565c0; margin-top: 25px;">Analysis and Recommendations</h3>
<div class="insights">' || INSIGHTS || '</div>
<p style="margin-top: 20px; font-size: 13px; color: #666;">
To manage alerts: "What alerts do I have?" or "Unsubscribe from this alert"
</p>
</div>
<div class="footer">
Ski Resort Analytics | Real Data from SKI_RESORT_DB<br>
Sent to: ' || :USER_EMAIL || '
</div>
</div>
</body></html>';

    -- Send the email
    CALL SYSTEM$SEND_EMAIL('MY_EMAIL_INT', :USER_EMAIL, :EMAIL_SUBJECT, :EMAIL_BODY, 'text/html');

    RETURN 'OK: Alert with real data sent to ' || :USER_EMAIL;
END;
$$;

-- =============================================================================
-- STEP 3: Schedule Alert - Creates subscription AND sends first alert
-- =============================================================================
CREATE OR REPLACE PROCEDURE SKI_RESORT_DB.AGENTS.SCHEDULE_ALERT(
    USER_EMAIL STRING,
    OVERALL_QUESTION STRING,
    ALERT_FREQUENCY STRING
)
RETURNS STRING
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    EXISTING_COUNT INTEGER;
BEGIN
    -- Validate frequency
    IF (ALERT_FREQUENCY NOT IN ('Daily', 'Weekly')) THEN
        RETURN 'ERROR: Frequency must be either Daily or Weekly';
    END IF;

    -- Check for duplicate subscription
    SELECT COUNT(*) INTO :EXISTING_COUNT
    FROM SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
    WHERE USER_EMAIL = :USER_EMAIL
      AND OVERALL_QUESTION = :OVERALL_QUESTION
      AND IS_ACTIVE = TRUE;

    IF (EXISTING_COUNT > 0) THEN
        RETURN 'INFO: You already have an active subscription for this question.';
    END IF;

    -- Insert the subscription
    INSERT INTO SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
        (USER_EMAIL, OVERALL_QUESTION, ALERT_FREQUENCY)
    VALUES
        (:USER_EMAIL, :OVERALL_QUESTION, :ALERT_FREQUENCY);

    -- Send the FIRST alert immediately
    CALL SKI_RESORT_DB.AGENTS.SEND_ALERT_NOW(:USER_EMAIL, :OVERALL_QUESTION);

    -- Update the alert record
    UPDATE SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
    SET LAST_SENT_AT = CURRENT_TIMESTAMP(),
        SEND_COUNT = 1
    WHERE USER_EMAIL = :USER_EMAIL
      AND OVERALL_QUESTION = :OVERALL_QUESTION
      AND IS_ACTIVE = TRUE;

    RETURN 'OK: Subscribed to ' || :ALERT_FREQUENCY || ' alerts! First email sent to ' || :USER_EMAIL || ' - check your inbox!';
END;
$$;

-- =============================================================================
-- STEP 4: Test Alert - One-time send without subscription
-- =============================================================================
CREATE OR REPLACE PROCEDURE SKI_RESORT_DB.AGENTS.TEST_ALERT(
    USER_EMAIL STRING,
    ALERT_TOPIC STRING
)
RETURNS STRING
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
BEGIN
    CALL SKI_RESORT_DB.AGENTS.SEND_ALERT_NOW(:USER_EMAIL, :ALERT_TOPIC);
    RETURN 'OK: Test alert sent to ' || :USER_EMAIL || ' (no subscription created).';
END;
$$;

-- =============================================================================
-- STEP 5: View My Alerts
-- =============================================================================
CREATE OR REPLACE PROCEDURE SKI_RESORT_DB.AGENTS.VIEW_MY_ALERTS(
    P_USER_EMAIL STRING
)
RETURNS STRING
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    ALERTS_JSON STRING;
BEGIN
    SELECT TO_JSON(ARRAY_AGG(OBJECT_CONSTRUCT(
        'alert_id', ALERT_ID,
        'question', OVERALL_QUESTION,
        'frequency', ALERT_FREQUENCY,
        'created_at', CREATED_AT,
        'last_sent', COALESCE(TO_VARCHAR(LAST_SENT_AT), 'Never'),
        'times_sent', SEND_COUNT
    ))) INTO :ALERTS_JSON
    FROM SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
    WHERE USER_EMAIL = :P_USER_EMAIL AND IS_ACTIVE = TRUE;

    IF (ALERTS_JSON IS NULL) THEN
        RETURN 'You have no active alert subscriptions.';
    END IF;

    RETURN ALERTS_JSON;
END;
$$;

-- =============================================================================
-- STEP 6: Unsubscribe Alert
-- =============================================================================
CREATE OR REPLACE PROCEDURE SKI_RESORT_DB.AGENTS.UNSUBSCRIBE_ALERT(
    USER_EMAIL STRING,
    OVERALL_QUESTION STRING
)
RETURNS STRING
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    ROWS_UPDATED INTEGER;
BEGIN
    UPDATE SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
    SET IS_ACTIVE = FALSE
    WHERE USER_EMAIL = :USER_EMAIL
      AND OVERALL_QUESTION ILIKE '%' || :OVERALL_QUESTION || '%'
      AND IS_ACTIVE = TRUE;

    ROWS_UPDATED := SQLROWCOUNT;

    IF (ROWS_UPDATED > 0) THEN
        RETURN 'OK: Successfully unsubscribed from ' || ROWS_UPDATED || ' alert(s).';
    ELSE
        RETURN 'No matching active alert found.';
    END IF;
END;
$$;

-- =============================================================================
-- STEP 7: Grant permissions
-- =============================================================================
GRANT USAGE ON PROCEDURE SKI_RESORT_DB.AGENTS.SEND_ALERT_NOW(STRING, STRING) TO ROLE SYSADMIN;
GRANT USAGE ON PROCEDURE SKI_RESORT_DB.AGENTS.SCHEDULE_ALERT(STRING, STRING, STRING) TO ROLE SYSADMIN;
GRANT USAGE ON PROCEDURE SKI_RESORT_DB.AGENTS.TEST_ALERT(STRING, STRING) TO ROLE SYSADMIN;
GRANT USAGE ON PROCEDURE SKI_RESORT_DB.AGENTS.VIEW_MY_ALERTS(STRING) TO ROLE SYSADMIN;
GRANT USAGE ON PROCEDURE SKI_RESORT_DB.AGENTS.UNSUBSCRIBE_ALERT(STRING, STRING) TO ROLE SYSADMIN;
GRANT SELECT, INSERT, UPDATE ON TABLE SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS TO ROLE SYSADMIN;
