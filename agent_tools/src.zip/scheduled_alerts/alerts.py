"""
Scheduled Alerts - Call Agent REST API, Email Response

Simple: Call agent → Get rich response → Email it
"""

import json
import requests
import markdown
import premailer
from datetime import datetime
from typing import Tuple, List, Dict, Optional
from snowflake.snowpark import Session

# Configuration
EMAIL_INTEGRATION = "MY_EMAIL_INT"
DATABASE = "SKI_RESORT_DB"
SCHEMA = "AGENTS"
AGENT_NAME = "RESORT_EXECUTIVE_DEV"

# Detect if running in Snowflake stored procedure
def _is_snowflake_runtime() -> bool:
    try:
        import _snowflake
        return True
    except ImportError:
        return False


class AgentClient:
    """Call Cortex Agent via REST API - works locally and in Snowflake."""
    
    def __init__(self, session: Session):
        self.session = session
        self.database = DATABASE
        self.schema = SCHEMA
        self.agent_name = AGENT_NAME
        self._in_snowflake = _is_snowflake_runtime()
        
        # Get connection details (only needed for local execution)
        if not self._in_snowflake:
            conn = session._conn._conn
            self.host = conn.host
            self._token = conn._rest._token
    
    def ask(self, question: str) -> str:
        """Ask the agent and return the answer."""
        if self._in_snowflake:
            return self._ask_via_snowflake_api(question)
        else:
            text, _ = self._invoke_agent_local(question)
            return text
    
    def _ask_via_snowflake_api(self, question: str) -> str:
        """Call agent using the working approach from snowflake-intelligence-awesome-tools."""
        # Get host - use environment or derive from session
        import os
        
        host = os.getenv("SNOWFLAKE_HOST")
        if not host:
            try:
                # Try to get from session
                account_row = self.session.sql("SELECT CURRENT_ACCOUNT()").collect()[0]
                account = str(account_row[0]).lower()
                # Standard Snowflake host pattern
                host = f"{account}.snowflakecomputing.com"
            except:
                host = None
        
        # Try to get token - multiple methods
        token = None
        
        # Method 1: SPCS token file
        try:
            token = open("/snowflake/session/token", "r").read().strip()
        except:
            pass
        
        # Method 2: Session conf (from working code)
        if not token:
            try:
                if hasattr(self.session, "conf"):
                    rest_conf = self.session.conf.get("rest")
                    if hasattr(rest_conf, "token"):
                        token = rest_conf.token
            except:
                pass
        
        # Method 3: Try _snowflake module for token
        if not token:
            try:
                import _snowflake
                # Use internal API as fallback
                return self._ask_via_internal_api(question)
            except ImportError:
                pass
        
        if not token or not host:
            return self._ask_via_internal_api(question)
        
        # Call agent with requests (the working approach)
        url = f"https://{host}/api/v2/databases/{self.database}/schemas/{self.schema}/agents/{self.agent_name}:run"
        headers = {
            "Authorization": f'Snowflake Token="{token}"',
            "Content-Type": "application/json",
        }
        body = {"messages": [{"role": "user", "content": [{"type": "text", "text": question}]}]}
        
        try:
            response = requests.post(url, headers=headers, json=body, stream=False, timeout=300)
            
            # Parse SSE response - exact pattern from working code
            final_text = ""
            chunks = response.text.split("\n\n")
            
            for chunk in chunks:
                lines = chunk.strip().split("\n")
                if len(lines) >= 2:
                    event_line = lines[0]
                    data_line = lines[1]
                    
                    if event_line == "event: response.text":
                        if data_line.startswith("data: "):
                            try:
                                parsed = json.loads(data_line[6:])
                                if "text" in parsed:
                                    final_text += parsed["text"]
                            except json.JSONDecodeError:
                                continue
            
            return final_text.strip() if final_text else "No response text"
            
        except Exception as e:
            return f"Request error: {str(e)}"
    
    def _ask_via_internal_api(self, question: str) -> str:
        """Fallback: Call agent using Snowflake's internal API."""
        import _snowflake
        
        endpoint = f"/api/v2/databases/{self.database}/schemas/{self.schema}/agents/{self.agent_name}:run"
        body = {"messages": [{"role": "user", "content": [{"type": "text", "text": question}]}]}
        
        try:
            response = _snowflake.send_snow_api_request(
                "POST", endpoint,
                {"Content-Type": "application/json", "Accept": "text/event-stream"},
                {}, body, None,
                300000  # 5 min timeout
            )
            
            if not response or not isinstance(response, dict):
                return "No response from internal API"
            
            content = response.get("content", "")
            if not content:
                return "Empty content from internal API"
            
            # Parse JSON array of events
            events = json.loads(content)
            answer = ""
            final_answer = ""
            
            for event in events:
                if not isinstance(event, dict):
                    continue
                event_type = event.get("event", "")
                data = event.get("data", {})
                
                if event_type == "response.text.delta":
                    if isinstance(data, dict) and "text" in data:
                        answer += str(data["text"])
                elif event_type == "response.text":
                    if isinstance(data, dict) and "text" in data:
                        final_answer = str(data["text"])
            
            result = final_answer if final_answer else answer
            return result.strip() if result else "No answer text in internal API response"
            
        except Exception as e:
            return f"Internal API error: {str(e)}"
    
    def _parse_event_list(self, events: list) -> str:
        """Parse list of event objects from _snowflake.send_snow_api_request."""
        answer = ""
        
        for event_wrapper in events:
            # Skip non-dict items
            if not isinstance(event_wrapper, dict):
                continue
                
            # Each item can have 'event' and 'data' keys
            event_type = event_wrapper.get("event", "")
            data = event_wrapper.get("data")
            
            # Skip if no data
            if data is None:
                continue
            
            # Only extract text from response.text events (not status/thinking)
            if event_type == "response.text.delta":
                if isinstance(data, dict) and "text" in data:
                    answer += str(data["text"])
                elif isinstance(data, str):
                    answer += data
            
            elif event_type == "response.text":
                if isinstance(data, dict) and "text" in data:
                    answer += str(data["text"])
                elif isinstance(data, str):
                    answer += data
            
            elif event_type == "response":
                # Final response - extract text content
                if isinstance(data, dict):
                    content = data.get("content")
                    if isinstance(content, list):
                        for item in content:
                            if isinstance(item, dict) and item.get("type") == "text":
                                text = item.get("text", "")
                                if text:
                                    answer = str(text)  # Use as final
                    elif isinstance(content, str):
                        answer = content
        
        return answer.strip()
    
    def _parse_sse_response(self, content: str) -> str:
        """Parse SSE stream content from agent response."""
        answer = ""
        current_event_type = None
        
        # Handle if content is already JSON (not SSE)
        if content.strip().startswith('{'):
            try:
                data = json.loads(content)
                if 'content' in data:
                    for item in data['content']:
                        if item.get('type') == 'text':
                            return item.get('text', '')
                return json.dumps(data)
            except json.JSONDecodeError:
                pass
        
        for line in content.split('\n'):
            if not line.strip():
                continue
            if line.startswith('event:'):
                current_event_type = line[6:].strip()
                continue
            if not line.startswith('data:'):
                continue
            
            data = line[5:].strip()
            if data == '[DONE]':
                break
                
            try:
                event = json.loads(data)
                # Only get text events, not thinking
                if current_event_type == 'response.text.delta' and 'text' in event:
                    answer += event['text']
                elif current_event_type == 'response.text' and 'text' in event:
                    answer += event['text']
                elif current_event_type == 'response' and 'content' in event:
                    for item in event['content']:
                        if item.get('type') == 'text':
                            answer = item.get('text', '')
            except json.JSONDecodeError:
                continue
        
        return answer.strip()
    
    def _invoke_agent_local(self, question: str) -> Tuple[str, List[Dict]]:
        """Invoke Cortex Agent via REST API."""
        url = f"https://{self.host}/api/v2/databases/{self.database}/schemas/{self.schema}/agents/{self.agent_name}:run"

        headers = {
            "Authorization": f"Snowflake Token=\"{self._token}\"",
            "Content-Type": "application/json",
            "Accept": "text/event-stream"
        }

        body = {"messages": [{"role": "user", "content": [{"type": "text", "text": question}]}]}

        response = requests.post(url, headers=headers, json=body, timeout=180, stream=True)

        if response.status_code != 200:
            return f"Error: {response.status_code} - {response.text}", []

        # Parse SSE stream - only get response.text events, NOT response.thinking
        answer_text = ""
        events = []
        current_event_type = None

        for line in response.iter_lines(decode_unicode=True):
            if not line:
                continue
            
            # Track event type
            if line.startswith('event:'):
                current_event_type = line[6:].strip()
                continue
            
            if not line.startswith('data:'):
                continue
                
            data = line[5:].strip()
            if data == '[DONE]':
                break
            
            try:
                event = json.loads(data)
                events.append(event)
                
                # Only extract from response.text events (NOT response.thinking)
                if current_event_type == 'response.text.delta':
                    # This is actual answer content
                    if 'text' in event:
                        answer_text += event['text']
                
                elif current_event_type == 'response.text':
                    # Complete text block
                    if 'text' in event:
                        answer_text += event['text']
                
                elif current_event_type == 'response':
                    # Final complete response - extract text content
                    if 'content' in event:
                        for item in event['content']:
                            if item.get('type') == 'text':
                                answer_text = item.get('text', '')  # Use this as final
                                
            except json.JSONDecodeError:
                continue

        return answer_text.strip(), events


def format_email(question: str, response: str, user_email: str) -> str:
    """Convert agent's markdown response to beautifully formatted HTML email.
    
    Uses premailer to inline CSS for email client compatibility.
    """
    timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    
    # Convert markdown to HTML with all extensions
    response_html = markdown.markdown(
        response, 
        extensions=["tables", "fenced_code", "nl2br", "sane_lists"]
    )
    
    # Build HTML with clean CSS (premailer will inline it)
    raw_html = f'''<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
    body {{ 
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; 
        margin: 0; 
        padding: 0; 
        background: #f6f9fc; 
    }}
    .container {{ 
        max-width: 700px; 
        margin: 0 auto; 
        background: #ffffff; 
        border-radius: 8px; 
        overflow: hidden; 
    }}
    .header {{ 
        background: linear-gradient(135deg, #1a73e8, #0d47a1); 
        color: #fff; 
        padding: 30px 40px; 
    }}
    .header h1 {{ 
        font-size: 20px; 
        margin: 0 0 10px 0; 
        font-weight: 600; 
    }}
    .header .meta {{ 
        font-size: 13px; 
        opacity: 0.9; 
    }}
    .content {{ 
        padding: 30px 40px; 
        color: #1f2937; 
        line-height: 1.7; 
        font-size: 14px; 
    }}
    /* Headers */
    h1 {{ color: #1a73e8; font-size: 22px; margin: 25px 0 15px 0; border-bottom: 2px solid #1a73e8; padding-bottom: 10px; }}
    h2 {{ color: #1a73e8; font-size: 18px; margin: 25px 0 12px 0; border-bottom: 1px solid #e0e0e0; padding-bottom: 8px; }}
    h3 {{ color: #1a73e8; font-size: 15px; margin: 20px 0 10px 0; }}
    /* Tables */
    table {{ width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 13px; }}
    th {{ background: #1a73e8; color: white; padding: 12px 15px; text-align: left; font-weight: 600; border: 1px solid #1a73e8; }}
    td {{ padding: 12px 15px; border: 1px solid #e0e0e0; }}
    tr:nth-child(even) {{ background: #f8f9fa; }}
    /* Lists */
    ul, ol {{ margin: 15px 0; padding-left: 25px; }}
    li {{ margin: 8px 0; line-height: 1.6; }}
    /* Other */
    p {{ margin: 12px 0; }}
    strong {{ color: #1a73e8; }}
    blockquote {{ background: #e8f0fe; border-left: 4px solid #1a73e8; margin: 20px 0; padding: 15px 20px; font-style: italic; }}
    hr {{ border: none; border-top: 2px solid #e0e0e0; margin: 25px 0; }}
    code {{ background: #f5f5f5; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 13px; }}
    .footer {{ 
        background: #f8f9fa; 
        padding: 20px 40px; 
        font-size: 12px; 
        color: #666666; 
        border-top: 1px solid #e0e0e0; 
    }}
    .footer strong {{ color: #1a73e8; }}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1 style="color:white;border:none;margin:0 0 10px 0;">🎿 {question[:100]}</h1>
        <div class="meta">Generated by Snowflake Intelligence | {timestamp}</div>
    </div>
    <div class="content">
        {response_html}
    </div>
    <div class="footer">
        <strong>Ski Resort Analytics</strong> | Powered by Snowflake Cortex<br>
        <span style="font-size:11px;color:#999;">To manage alerts: "What alerts do I have?" or "Unsubscribe from this alert"</span>
    </div>
</div>
</body>
</html>'''
    
    # Use premailer to inline all CSS for email client compatibility
    return premailer.transform(raw_html)


def send_email(session: Session, recipient: str, subject: str, html: str) -> bool:
    """Send email via Snowflake."""
    escaped_html = html.replace("'", "''")
    escaped_subject = subject.replace("'", "''")
    session.sql(f"""
        CALL SYSTEM$SEND_EMAIL(
            '{EMAIL_INTEGRATION}',
            '{recipient}',
            '{escaped_subject}',
            '{escaped_html}',
            'text/html'
        )
    """).collect()
    return True


# =============================================================================
# ENTRY POINTS
# =============================================================================

def send_alert_now(session: Session, user_email: str, question: str) -> str:
    """Send alert: Call agent → Get response → Email it"""
    client = AgentClient(session)
    response = client.ask(question)
    html = format_email(question, response, user_email)
    subject = f"🎿 {question[:60]}"
    send_email(session, user_email, subject, html)
    return json.dumps({"success": True, "response_length": len(response)})


def process_alerts(session: Session) -> str:
    """Process scheduled alerts."""
    client = AgentClient(session)
    day_of_week = datetime.now().strftime("%A")
    
    frequency_filter = "ALERT_FREQUENCY IN ('Daily', 'Weekly')" if day_of_week == "Monday" else "ALERT_FREQUENCY = 'Daily'"
    
    alerts_df = session.sql(f"""
        SELECT ALERT_ID, USER_EMAIL, OVERALL_QUESTION
        FROM {DATABASE}.{SCHEMA}.SCHEDULED_ALERTS
        WHERE IS_ACTIVE = TRUE AND {frequency_filter}
    """).to_pandas()
    
    results = []
    emails_sent = 0
    
    for _, alert in alerts_df.iterrows():
        alert_id = alert["ALERT_ID"]
        user_email = alert["USER_EMAIL"]
        question = alert["OVERALL_QUESTION"]
        
        response = client.ask(question)
        html = format_email(question, response, user_email)
        subject = f"🎿 {question[:60]}"
        send_email(session, user_email, subject, html)
        
        emails_sent += 1
        session.sql(f"""
            UPDATE {DATABASE}.{SCHEMA}.SCHEDULED_ALERTS
            SET LAST_SENT_AT = CURRENT_TIMESTAMP(), SEND_COUNT = SEND_COUNT + 1
            WHERE ALERT_ID = {alert_id}
        """).collect()
        
        results.append({"alert_id": int(alert_id), "status": "success"})
    
    return json.dumps({
        "timestamp": datetime.now().isoformat(),
        "total_alerts": len(alerts_df),
        "emails_sent": emails_sent,
        "results": results
    })
