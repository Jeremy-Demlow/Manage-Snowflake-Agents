# Scheduled Intelligence Alerts

Subscribe to recurring ski resort analyses delivered via email. **Works with Snowflake Intelligence for dynamic AI-generated content.**

## Key Features

1. **Any Question** - Subscribe to any question, not just hardcoded ones
2. **Dynamic AI Content** - Cortex Analyst generates insights dynamically
3. **Alert Management** - Full CRUD via notebook or agent
4. **Email Delivery** - Beautiful HTML emails via Snowflake

## Quick Start

### 1. Create Database Objects
```bash
snow sql -f schedule_analysis.sql --connection snowflake_agents
```

### 2. Subscribe via Agent
```
User: "Subscribe me to daily lift wait time updates"
Agent: ✅ "You're subscribed! You'll receive daily updates at 8am."
```

### 3. Test with Notebook
Open `notebooks/test_scheduled_alerts.ipynb` to:
- Subscribe/view/delete alerts interactively
- Test dynamic content generation with Cortex
- Send test emails

## Files

| File | Purpose |
|------|---------|
| `schedule_analysis.sql` | Table + agent tool procedures |
| `alerts.py` | Processing logic (Snowpark) |
| `notebooks/test_scheduled_alerts.ipynb` | Interactive testing |

## Dynamic Content with Cortex

Instead of hardcoded HTML, let SI generate insights for **any question**:

```python
# In Snowflake Notebooks
insights = get_cortex_insights("What were the busiest lifts yesterday?")
html = generate_dynamic_email(question, insights['text'], insights['data'])
send_email(session, email, subject, html)
```

## Alert Management

```python
# View your alerts
session.call('SKI_RESORT_DB.AGENTS.VIEW_MY_ALERTS', 'your@email.com')

# Unsubscribe by keyword
session.call('SKI_RESORT_DB.AGENTS.UNSUBSCRIBE_ALERT', 'your@email.com', 'lift')

# Bulk cleanup (SQL)
session.sql("""
    UPDATE SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
    SET IS_ACTIVE = FALSE
    WHERE USER_EMAIL = 'your@email.com'
""")

# Delete specific alert
session.sql("""
    UPDATE SKI_RESORT_DB.AGENTS.SCHEDULED_ALERTS
    SET IS_ACTIVE = FALSE
    WHERE ALERT_ID = 123
""")
```

## Database Objects

All in `SKI_RESORT_DB.AGENTS`:

| Object | Type | Description |
|--------|------|-------------|
| `SCHEDULED_ALERTS` | Table | Stores subscriptions |
| `SCHEDULE_ALERT` | Procedure | Agent tool - subscribe |
| `VIEW_MY_ALERTS` | Procedure | Agent tool - list |
| `UNSUBSCRIBE_ALERT` | Procedure | Agent tool - cancel |
| `PROCESS_SCHEDULED_ALERTS` | Procedure | Process all (Snowpark) |
| `ALERTS_STAGE` | Stage | Snowpark code |

## Architecture

```
User subscribes → SCHEDULED_ALERTS table
                          ↓
              [Daily Task / Manual Trigger]
                          ↓
         PROCESS_SCHEDULED_ALERTS procedure
                          ↓
              Cortex Analyst (dynamic insights)
                          ↓
              Generate HTML email
                          ↓
              SYSTEM$SEND_EMAIL → 📧
```
