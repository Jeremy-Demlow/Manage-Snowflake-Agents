"""
Web scraping tools package for competitive analysis
"""
