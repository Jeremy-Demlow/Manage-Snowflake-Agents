"""
ML Observability for Ski Resort Forecasting

Provides prediction logging and drift detection.
"""
