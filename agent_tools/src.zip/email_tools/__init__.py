"""
Email tools package for Snowflake Intelligence agents
"""
