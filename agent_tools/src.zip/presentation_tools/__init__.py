"""
Presentation tools package for Snowflake Intelligence agents
Creates PowerPoint reports from agent conversations
"""
